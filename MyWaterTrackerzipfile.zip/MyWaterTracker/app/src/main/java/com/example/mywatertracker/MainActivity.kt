package com.example.mywatertracker

import android.app.*
import android.content.*
import android.os.*
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {

    companion object {
        const val CHANNEL_ID = "WaterTrackerChannel"
        const val NOTIFICATION_ID = 1
        const val ACTION_DRINK = "com.example.mywatertracker.DRINK"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel()
        requestNotificationPermission()
        startWaterService()

        setContent {
            var waterLevel by remember { mutableStateOf(2500f) }

            // BroadcastReceiver to update UI when service sends update
            DisposableEffect(Unit) {
                val receiver = object : BroadcastReceiver() {
                    override fun onReceive(context: Context?, intent: Intent?) {
                        waterLevel = intent?.getFloatExtra("water_level", waterLevel) ?: waterLevel
                    }
                }
                registerReceiver(receiver, IntentFilter("UPDATE_WATER_LEVEL"))
                onDispose { unregisterReceiver(receiver) }
            }

            Surface(
                modifier = Modifier.fillMaxSize(),
                color = MaterialTheme.colorScheme.background
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("💧 My Water Tracker", style = MaterialTheme.typography.headlineMedium)
                    Spacer(modifier = Modifier.height(20.dp))
                    Text("Current Water Level: ${"%.1f".format(waterLevel)} ml")
                    Spacer(modifier = Modifier.height(20.dp))
                    Button(onClick = {
                        val intent = Intent(this@MainActivity, WaterService::class.java)
                        intent.action = ACTION_DRINK
                        ContextCompat.startForegroundService(this@MainActivity, intent)
                    }) {
                        Text("Drank a Glass of Water (+250ml)")
                    }
                }
            }
        }
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    private fun startWaterService() {
        val intent = Intent(this, WaterService::class.java)
        ContextCompat.startForegroundService(this, intent)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Water Tracker Notifications",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    // Inner Service Class (no separate file)
    class WaterService : Service() {
        private var waterLevel = 2500f
        private val handler = Handler(Looper.getMainLooper())
        private val decreaseTask = object : Runnable {
            override fun run() {
                waterLevel -= 0.144f
                sendWaterUpdate()
                updateNotification()
                handler.postDelayed(this, 5000)
            }
        }

        override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
            if (intent?.action == ACTION_DRINK) {
                waterLevel += 250f
                sendWaterUpdate()
                updateNotification()
            } else {
                startForeground(NOTIFICATION_ID, createNotification())
                handler.postDelayed(decreaseTask, 5000)
            }
            return START_STICKY
        }

        override fun onDestroy() {
            super.onDestroy()
            handler.removeCallbacks(decreaseTask)
        }

        private fun sendWaterUpdate() {
            val intent = Intent("UPDATE_WATER_LEVEL")
            intent.putExtra("water_level", waterLevel)
            sendBroadcast(intent)
        }

        private fun updateNotification() {
            val notificationManager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.notify(NOTIFICATION_ID, createNotification())
        }

        private fun createNotification(): Notification {
            return NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("My Water Tracker")
                .setContentText("Current level: ${"%.1f".format(waterLevel)} ml")
                .setSmallIcon(android.R.drawable.ic_menu_compass)
                .setOngoing(true)
                .build()
        }

        override fun onBind(intent: Intent?): IBinder? = null
    }
}
